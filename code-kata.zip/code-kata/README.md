# Execution Steps

Navigate to Problem1 Folder

Run:
1)docker build -t parser .
2)docker run -v $(pwd)/input:/app/input -v $(pwd)/output:/app/output parser


Navigate to Problem2 Folder

Run:
1)docker build -t anonymize .
2)docker run -v $(pwd)/input:/app/input -v $(pwd)/output:/app/output anonymize


Both will generate the output csv files in the output folder of the respective directories.

# Approach

For Problem1:
Used normal parsing by reading the spec file.

For Problem2:
-Used dask for parallel processing. 
-Would have opted for Spark but felt Dask is sufficient of 2GB File. Generating the output in 1.5 to 2 min.