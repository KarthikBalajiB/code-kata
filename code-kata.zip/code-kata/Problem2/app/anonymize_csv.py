import dask.dataframe as dd
import random
import string
import os
import pandas as pd

# Function to anonymize the columns
def anonymize_column(val):
    if isinstance(val, str):
        return ''.join(random.choices(string.ascii_lowercase, k=len(val)))
    return val

# Function to anonymize the data
def anonymize_data_chunk(df_chunk):
    # Apply the anonymization functions to the relevant columns
    df_chunk['first_name'] = df_chunk['first_name'].apply(anonymize_column)
    df_chunk['last_name'] = df_chunk['last_name'].apply(anonymize_column)
    df_chunk['address'] = df_chunk['address'].apply(anonymize_column)
    # 'date_of_birth' column remains untouched
    return df_chunk

# Function to process and anonymize large CSV in parallel using Dask
def process_csv(input_file, output_file):
    # Read the large CSV file into a Dask dataframe
    df = dd.read_csv(input_file)

    # Define the meta parameter (the expected schema after anonymization)
    # This is necessary to tell Dask the schema of the output DataFrame
    meta = pd.DataFrame(columns=['first_name', 'last_name', 'address', 'date_of_birth'])

    # Apply the anonymization function to the data
    anonymized_df = df.map_partitions(anonymize_data_chunk, meta=meta)

    # Write the result to the output CSV
    anonymized_df.to_csv(output_file, index=False, single_file=True)

# Main function
def main():
    input_file = '/app/input/input.csv'
    output_file = '/app/output/output.csv'

    print(f"Starting to process {input_file}...")
    process_csv(input_file, output_file)
    print(f"Processing complete. Output saved to {output_file}")

if __name__ == "__main__":
    main()
