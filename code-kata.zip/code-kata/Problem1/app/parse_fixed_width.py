import csv
import json
import os

def parse_fixed_width():
    input_folder = "/app/input/"
    output_folder = "/app/output/"
    
    # Load spec file
    with open(os.path.join(input_folder, "spec.json"), "r", encoding="utf-8") as spec_file:
        spec = json.load(spec_file)
    
    offsets = list(map(int, spec["Offsets"]))
    column_names = spec["ColumnNames"]
    fixed_width_encoding = spec["FixedWidthEncoding"]
    delimited_encoding = spec["DelimitedEncoding"]
    include_header = spec["IncludeHeader"] == "True"
    
    # Read the fixed-width input file
    input_file_path = os.path.join(input_folder, "fixed_width_input.txt")
    with open(input_file_path, "r", encoding=fixed_width_encoding) as input_file:
        lines = input_file.readlines()

    # Parse the fixed-width data
    parsed_data = []
    for line in lines:
        parsed_row = []
        position = 0
        for width in offsets:
            parsed_row.append(line[position:position + width].strip())
            position += width
        parsed_data.append(parsed_row)

    # Write to a CSV file
    output_file_path = os.path.join(output_folder, "parsed_output.csv")
    with open(output_file_path, "w", newline="", encoding=delimited_encoding) as csv_file:
        writer = csv.writer(csv_file)
        if include_header:
            writer.writerow(column_names)
        writer.writerows(parsed_data)

if __name__ == "__main__":
    parse_fixed_width()
